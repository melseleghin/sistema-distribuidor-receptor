import java.net.*;
import java.io.*;

public class Reativo
{
 public static void main (String[] args)
 {
  try
  {
   ServerSocket pedido =
   new ServerSocket (10000);

   Socket conexao = 
   pedido.accept();

   BufferedReader receptor = // textos
   new BufferedReader (
   new InputStreamReader (
   conexao.getInputStream()));
   /*
   DataInputStream receptor = // tps primitivos
   new DataInputStream (
   conexao.getInputStream());
   // readInt e readFloat são alguns metodos
   
   ObjectInputStream receptor = // objetos
   new ObjectInputStream (
   conexao.getInputStream());
   // readObject é o cara
   */
   PrintWriter transmissor = // textos
   new PrintWriter (
   conexao.getOutputStream());
   /*
   DataOutputStream transmissor = // tps primitivos
   new DataOutputStream (
   conexao.getOutputStream());
   // writeInt e writeFloat são alguns métodos
   
   ObjectOutputStream transmissor = // objetos
   new ObjectOutputStream (
   conexao.getOutputStream());
   // writeObject é o cara
   */

   String texto;
   do
   {
    texto=receptor.readLine();
    System.out.println(texto);
   }
   while (!texto.toUpperCase().equals("FIM"));

   transmissor.close();
   receptor.close();
   conexao.close();
   pedido.close();
  }
  catch (Exception erro)
  {
   System.err.println(erro.getMessage());
  }
 }
}