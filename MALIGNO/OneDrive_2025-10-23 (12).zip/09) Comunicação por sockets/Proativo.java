import java.net.*;
import java.io.*;

public class Proativo
{
 public static void main (String[] args)
 {
  try
  {
   Socket conexao =
   new Socket ("172.16.1.183",10000);

   BufferedReader receptor = // textos
   new BufferedReader (
   new InputStreamReader (
   conexao.getInputStream()));
   /*
   DataInputStream receptor = // tps primitivos
   new DataInputStream (
   conexao.getInputStream());
   // readInt e readFloat são alguns metodos
   
   ObjectInputStream receptor = // objetos
   new ObjectInputStream (
   conexao.getInputStream());
   // readObject é o cara
   */

   PrintWriter transmissor = // textos
   new PrintWriter (
   conexao.getOutputStream());
   /*
   DataOutputStream transmissor = // tps primitivos
   new DataOutputStream (
   conexao.getOutputStream());
   // writeInt e writeFloat são alguns métodos
   
   ObjectOutputStream transmissor = // objetos
   new ObjectOutputStream (
   conexao.getOutputStream());
   // writeObject é o cara
   */

   BufferedReader teclado =
   new BufferedReader (
   new InputStreamReader (
   System.in));

   String texto;
   do
   {
    texto=teclado.readLine();
    transmissor.println(texto); // envio
    transmissor.flush(); // envio imediato
   }
   while (!texto.toUpperCase().equals("FIM"));

   transmissor.close();
   receptor.close();
   conexao.close();
  }
  catch (Exception erro)
  {
   System.err.println(erro.getMessage());
  }
 }
}