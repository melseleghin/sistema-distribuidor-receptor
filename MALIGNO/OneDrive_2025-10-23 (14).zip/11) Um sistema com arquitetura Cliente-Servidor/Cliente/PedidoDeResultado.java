public class PedidoDeResultado extends Comunicado
{}
