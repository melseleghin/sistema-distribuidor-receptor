public class PedidoParaSair extends Comunicado
{}
